// src/App.js
import React, { useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import MobileList from "./MobileList";
import Cart from "./Cart";
import "./App.css";
import Nav from "./Nav";
import SignIn from "./SignIn";
import SignUp from "./SignUp";
import Payment from "./Payment";
import DeteleMobile from "./curd/DeleteMobile";
import AddMobile from "./curd/AddMobile";
import UpdateMobile from "./curd/UpdateMobile";

const App = () => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (mobile) => {
    setCartItems((prevItems) => [...prevItems, mobile]);
  };

  
  return (
    <div >
        
      <BrowserRouter>
      <Nav/>
      <Routes>
      <Route path="/cart" element={<Cart cartItems={cartItems} />} >
      </Route>
          {/* Pass addToCart to MobileList */}
          <Route path="/mob" element={<MobileList addToCart={addToCart} />} ></Route>
          <Route path="/in" element={<SignIn/>} ></Route>
          <Route path="/up" element={<SignUp/>} > </Route>
          <Route path="/del" element={<DeteleMobile/>}></Route>
          <Route path="/update" element={<UpdateMobile/>}></Route>
          <Route path="/add" element={<AddMobile/>}></Route>
          <Route path="/payment" element={<Payment cartItems={cartItems} />} ></Route>
      </Routes>
      
      </BrowserRouter>
    </div>
  );
};

export default App;
