import React, { useState } from 'react';
import api from '../Api';
const DeleteMobile = () => {
    const [id, setId] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await api.delete(`mobile/${id}`); 
            console.log('Mobile deleted:', response.data);
            alert('Mobile deleted successfully!');
            setId('');
        } catch (error) {
            console.error('Error deleting mobile:', error);
            alert('Failed to delete mobile. Please try again.');
        }
    };

    return (
        <div>
            <h1>Delete Mobile</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    ID (required):
                    <input
                        type="number"
                        value={id}
                        onChange={(e) => setId(e.target.value)}
                        placeholder="Enter Mobile ID"
                        required
                    />
                </label>
                <br />
                <button type="submit">Delete Mobile</button>
            </form>
        </div>
    );
};

export default DeleteMobile;

