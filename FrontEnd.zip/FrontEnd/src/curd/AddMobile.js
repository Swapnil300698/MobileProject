import React, { useState } from 'react';
import api from '../Api'; // Import your Axios instance

const AddMobile = () => {
    // State to hold user input data
    const [formData, setFormData] = useState({
        id: '',
        mName: '',
        brand: '',
        price: '',
        image: '',
    });

    // Handle input changes and update state
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    // Submit data to API
    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent page refresh
        try {
            const response = await api.post('mobile', formData); // Use api instance
            console.log('Mobile added:', response.data);
            alert('Mobile added successfully!');
            // Clear the form
            setFormData({
                id: '',
                mName: '',
                brand: '',
                price: '',
                image: '',
            });
        } catch (error) {
            console.error('Error adding mobile:', error);
            alert('Failed to add mobile. Please try again.');
        }
    };

    return (
        <div>
            <h1>Add a New Mobile</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    ID:
                    <input
                        type="number"
                        name="id"
                        value={formData.id}
                        onChange={handleInputChange}
                        placeholder="Enter Mobile ID"
                        required
                    />
                </label>
                <br />
                <label>
                    Mobile Name:
                    <input
                        type="text"
                        name="mName"
                        value={formData.mName}
                        onChange={handleInputChange}
                        placeholder="Enter Mobile Name"
                        required
                    />
                </label>
                <br />
                <label>
                    Brand:
                    <input
                        type="text"
                        name="brand"
                        value={formData.brand}
                        onChange={handleInputChange}
                        placeholder="Enter Brand"
                        required
                    />
                </label>
                <br />
                <label>
                    Price:
                    <input
                        type="number"
                        name="price"
                        value={formData.price}
                        onChange={handleInputChange}
                        placeholder="Enter Price"
                        required
                    />
                </label>
                <br />
                <label>
                    Image URL:
                    <input
                        type="url"
                        name="image"
                        value={formData.image}
                        onChange={handleInputChange}
                        placeholder="Enter Image URL"
                        required
                    />
                </label>
                <br />
                <button type="submit">Add Mobile</button>
            </form>
        </div>
    );
};

export default AddMobile;
