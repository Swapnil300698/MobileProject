import React, { useState } from 'react';
import api from '../Api'; // Import your Axios instance

const UpdateMobile = () => {
    const [formData, setFormData] = useState({
        id: '',
        mName: '',
        brand: '',
        price: '',
        image: '',
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await api.put(`mobile/${formData.id}`, formData); // Update mobile by ID
            console.log('Mobile updated:', response.data);
            alert('Mobile updated successfully!');
            // Clear the form
            setFormData({
                id: '',
                mName: '',
                brand: '',
                price: '',
                image: '',
            });
        } catch (error) {
            console.error('Error updating mobile:', error);
            alert('Failed to update mobile. Please try again.');
        }
    };

    return (
        <div>
            <h1>Update Mobile</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    ID (required):
                    <input
                        type="number"
                        name="id"
                        value={formData.id}
                        onChange={handleInputChange}
                        placeholder="Enter Mobile ID"
                        required
                    />
                </label>
                <br />
                <label>
                    Mobile Name:
                    <input
                        type="text"
                        name="mName"
                        value={formData.mName}
                        onChange={handleInputChange}
                        placeholder="Update Mobile Name"
                    />
                </label>
                <br />
                <label>
                    Brand:
                    <input
                        type="text"
                        name="brand"
                        value={formData.brand}
                        onChange={handleInputChange}
                        placeholder="Update Brand"
                    />
                </label>
                <br />
                <label>
                    Price:
                    <input
                        type="number"
                        name="price"
                        value={formData.price}
                        onChange={handleInputChange}
                        placeholder="Update Price"
                    />
                </label>
                <br />
                <label>
                    Image URL:
                    <input
                        type="url"
                        name="image"
                        value={formData.image}
                        onChange={handleInputChange}
                        placeholder="Update Image URL"
                    />
                </label>
                <br />
                <button type="submit">Update Mobile</button>
            </form>
        </div>
    );
};

export default UpdateMobile;
