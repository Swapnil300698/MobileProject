import React, { useState, useEffect } from "react";
import api from "./Api";
import "./MobileList.css";

const MobileList = ({ addToCart }) => {
  const [mobiles, setMobiles] = useState([]);
  const [originalMobiles, setOriginalMobiles] = useState([]); // Store the original list

  // Fetch mobiles from backend
  useEffect(() => {
    api.get("/mobile")
      .then((response) => {
        setMobiles(response.data);
        setOriginalMobiles(response.data); // Backup the original list
      })
      .catch((error) => {
        console.error("Error fetching mobiles:", error);
      });
  }, []);

  // Filter functions
  const filterByBrand = (brand) => {
    setMobiles(originalMobiles.filter((mobile) => mobile.brand === brand));
  };

  return (
    <div className="a">
      <div>
        <button className="k" onClick={() => filterByBrand("moto")}>Moto</button>
        <button className="k" onClick={() => filterByBrand("vivo")}>Vivo</button>
        <button className="k" onClick={() => filterByBrand("samsung")}>Samsung</button>
        <button className="k" onClick={() => filterByBrand("headphone")}>Headphones</button>
        <button className="k" onClick={() => setMobiles(originalMobiles)}>Reset</button>
      </div>
      <div>
        {mobiles.map((mobile) => (
          <div key={mobile.id} className="box">
            <img src={mobile.image} className="im" alt="mobile" />
            <h3>{mobile.mName}</h3>
            <p>Brand: {mobile.brand}</p>
            <p>Price: ${mobile.price}</p>
            <button onClick={() => addToCart(mobile)}>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MobileList;
