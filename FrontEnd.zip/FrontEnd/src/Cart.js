import React, { useState } from "react";
import "./cart.css";
import { Link } from "react-router-dom";

const Cart = ({ cartItems: initialCartItems }) => {
  const [cartItems, setCartItems] = useState(initialCartItems);

  const totalPrice = cartItems.reduce((sum, item) => sum + item.price, 0);

  function rem(index) {
    const updatedCart = cartItems.filter((_, i) => i !== index);
    setCartItems(updatedCart);
  }

  return (
    <div className="bg">
      <h2>Cart</h2>
      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          {cartItems.map((item, index) => (
            <div key={index} style={{ marginBottom: "10px" }}>
              <img src={item.image} className="im"/>
              <h3>{item.mName}</h3>
              <p>Brand: {item.brand}</p>
              <p>Price: ${item.price}</p>
              <button onClick={() => rem(index)}>Remove From Cart</button>
            </div>
          ))}
          <h3>Total: ${totalPrice.toFixed(2)}</h3>
        </div>
      )}

     <Link to={"/payment"} ><span className="t">Go to Payments </span></Link>

    </div>
  );
};

export default Cart;
