import { Link } from "react-router-dom";
import "./Nav.css";

export default function Nav(){
   return(
      
    <nav className="nv"> 
      
    <big className="ab"><big>SundarBan</big></big>
  
   <Link to={"/mob"} ><span className="b">Mobiles</span></Link>
   <Link to={"/in"} ><span className="c">SignIn</span></Link>
   <Link to={"/up"} ><span className="d">SignUp</span></Link>
   <Link to={"/cart"} > <span className="a">Cart</span></Link>

   </nav>
   )
}