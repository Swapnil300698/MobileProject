// src/api.js
import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8080", // Base URL of your backend
});

export default api;

//for internship of students
//https://pulse.itvedant.com/index.php/course/syllabus?id=246
