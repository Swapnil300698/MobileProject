import React, { useState } from "react";
import "./Payment.css";
import api from "./Api"; // Import Axios instance

const Payment = ({ cartItems }) => {
  const [paymentMethod, setPaymentMethod] = useState("");
  const [isPaid, setIsPaid] = useState(false);
  const [error, setError] = useState(null);

  const totalPrice = cartItems.reduce((sum, item) => sum + item.price, 0);

  const handlePayment = async () => {
    if (!paymentMethod) {
      alert("Please select a payment method.");
      return;
    }

    try {
      const orders = cartItems.map((item) => ({
        mName: item.name,
        brand: item.brand,
        price: item.price,
        image: item.image,
        paymentMethod: paymentMethod,
      }));

      const responses = await Promise.all(
        orders.map((order) => api.post("/mobile/order/84", order))
      );

      console.log("Orders stored successfully:", responses.map((res) => res.data));
      setIsPaid(true);
      setError(null);
      alert("Payment successful! Thank you for your purchase.");
    } catch (err) {
      console.error("Error storing orders:", err.response || err.message);
      setError(err.response?.data || "An error occurred while processing your order.");
    }
  };

  return (
    <div className="payment-bg">
      <h2>Payment</h2>
      {cartItems.length === 0 ? (
        <p>Your cart is empty. Please add items to proceed to payment.</p>
      ) : isPaid ? (
        <p>Payment successful! Your order is being processed.</p>
      ) : (
        <div>
          <h3>Total Amount: ${totalPrice.toFixed(2)}</h3>
          <div className="payment-methods">
            <h4>Select Payment Method:</h4>
            <label>
              <input
                type="radio"
                name="paymentMethod"
                value="Credit Card"
                onChange={(e) => setPaymentMethod(e.target.value)}
              />
              Credit Card
            </label>
            <label>
              <input
                type="radio"
                name="paymentMethod"
                value="Debit Card"
                onChange={(e) => setPaymentMethod(e.target.value)}
              />
              Debit Card
            </label>
            <label>
              <input
                type="radio"
                name="paymentMethod"
                value="PayPal"
                onChange={(e) => setPaymentMethod(e.target.value)}
              />
              PayPal
            </label>
            <label>
              <input
                type="radio"
                name="paymentMethod"
                value="Cash on Delivery"
                onChange={(e) => setPaymentMethod(e.target.value)}
              />
              Cash on Delivery
            </label>
          </div>
          <button className="pay-button" onClick={handlePayment}>
            Pay Now
          </button>
          {error && <p style={{ color: "red" }}>Error: {error}</p>}
        </div>
      )}
    </div>
  );
};

export default Payment;
