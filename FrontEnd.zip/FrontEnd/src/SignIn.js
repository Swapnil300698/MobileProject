import React, { useState } from "react";
import axios from "./Api"; // Import your API instance
import "./SignIn.css";
const Login = () => {
  const [username, setUsername] = useState(""); // State for username
  const [password, setPassword] = useState(""); // State for password
  const [message, setMessage] = useState(""); // State for success or failure message

  // Function to handle the sign-in process
  const handleSignIn = async (e) => {
    e.preventDefault(); // Prevent form submission from refreshing the page

    try {
      // Make a request to the /signin endpoint
      const response = await axios.post("/signin", null, {
        params: { u: username, p: password }, // Pass username and password as query parameters
      });

      setMessage(response.data); // Set the message returned by the backend
    } catch (error) {
      // Handle errors
      setMessage("An error occurred. Please try again later.");
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }} className="signin-container">
      <h1>Login</h1>
      <form onSubmit={handleSignIn} className="signin-form">
        <div >
          <label>
            Username:
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              
             
            />
          </label>
        </div>
        <div style={{ marginBottom: "15px" }}>
          <label>
            Password:
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
             
            />
          </label>
        </div>
        <button type="submit" style={{ marginTop: "10px" }}>Sign In</button>
      </form>
      {message && (
        <p style={{ color: message.includes("succusessful") ? "green" : "red", marginTop: "20px" }}>
          {message}
        </p>
      )}
    </div>
  );
};

export default Login;
