import React, { useState } from "react";
import api from "./Api";
import "./SignUp.css";
import { Link } from "react-router-dom";

function SignUp() {
  const [id, setId] = useState("");
  const [uName, setUName] = useState("");
  const [pass, setPass] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/signup", {
        id,
        uName,
        pass,
        email,
        mobile,
      });
      setMessage("Signup successful! Welcome, " + response.data.uName);
    } catch (error) {
      setMessage("Signup failed. Please try again.");
      console.error("Error during sign-up:", error);
    }
  };

  return (
    <div className="signup-container">
      <h2>Sign Up</h2>
      <form className="signup-form" onSubmit={handleSubmit}>
        <label>ID:</label>
        <input
          type="text"
          value={id}
          onChange={(e) => setId(e.target.value)}
          placeholder="Enter your ID"
        />

        <label>Username:</label>
        <input
          type="text"
          value={uName}
          onChange={(e) => setUName(e.target.value)}
          placeholder="Choose a username"
        />

        <label>Password:</label>
        <input
          type="password"
          value={pass}
          onChange={(e) => setPass(e.target.value)}
          placeholder="Choose a password"
        />

        <label>Email:</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
        />

        <label>Mobile:</label>
        <input
          type="text"
          value={mobile}
          onChange={(e) => setMobile(e.target.value)}
          placeholder="Enter your mobile number"
        />

        <button type="submit">Sign Up</button>
      </form>
      {message && (
        <p className={`signup-message ${message.includes("failed") ? "error" : "success"}`}>
          {message}
        </p>
      )}


 
    </div>
  );
}

export default SignUp;






