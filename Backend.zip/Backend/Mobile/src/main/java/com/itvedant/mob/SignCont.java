package com.itvedant.mob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class SignCont {
    @Autowired
    SignSer ser;
	@PostMapping("/signup")
	public SignUp insert(@RequestBody SignUp sg) {
		return ser.add(sg);
	}
	@PostMapping("/signin")
	public String In(@RequestParam String u ,@RequestParam String p) {
		return ser.signIn(u, p);
	}
}
