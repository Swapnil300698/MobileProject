package com.itvedant.mob;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SignSer {
  @Autowired
  SignJpa sj;
  public SignUp add(SignUp sg) {
	  return sj.save(sg);
  }
  
  public String signIn(String u, String p) {
	  List<SignUp> sgl= sj.findAll();
	  boolean f = true;
	  for(int i=0;i<sgl.size();i++) {
	  if(u.equals(sgl.get(i).getuName())  && p.equals(sgl.get(i).getPass())) {  
		  f= false;
		  return "Sign In succusessful...";
	  }
	  }
	   if(f) {
		   return "Failed....";
	   }
	   else {
		   return "Sign Up succeful";
	   }
	  
  }
}
