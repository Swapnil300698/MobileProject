package com.itvedant.mob;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MyJpa extends JpaRepository<MobileB, Integer>{
   
}
@Repository
interface SignJpa extends JpaRepository<SignUp, Integer>{
	   
}

@Repository
interface OrderJpa extends JpaRepository<OrderM, Integer>{
	   
}
