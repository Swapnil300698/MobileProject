package com.itvedant.mob;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import jakarta.persistence.EntityNotFoundException;

@Service
public class MyService {
  @Autowired
  private MyJpa jpa;
  
  @Autowired
  private OrderJpa ojpa;
  public MobileB createM(MobileF mf) {
	  MobileB mob = new MobileB();
	  mob.setId(mf.getId());
	  mob.setmName(mf.getmName());
	  mob.setBrand(mf.getBrand());
	  mob.setPrice(mf.getPrice());
	  mob.setImage(mf.getImage());
	  this.jpa.save(mob);
	  return mob;
  }
  public List<MobileB> showM() {
	  return this.jpa.findAll();
  }

  public MobileB getM(Integer id) throws Exception {
	MobileB mb =  jpa.findById(id).orElse(null);
	if(mb==null) {
		throw new Exception("Mobile not found");
	}
	return mb;
  }
  
  public MobileB updateM(Integer id,MobileF mf) throws Exception {
	  MobileB mb =  jpa.findById(id).orElse(null);
	  if(mb==null) {
		  throw new Exception("Mobile not found");
	  }
	  else {
		 
		  mb.setId(mf.getId());
		  mb.setmName(mf.getmName());
		  mb.setBrand(mf.getBrand());
		  mb.setPrice(mf.getPrice());
		  mb.setImage(mf.getImage());
		  this.jpa.save(mb);
		  return mb;
	  }
  }
  
  public Page<MobileB> showPM(int page, int size, String sortBy) {
	  return this.jpa.findAll(PageRequest.of(page, size, Sort.by(sortBy)));
  }
  
  public void deleteM(int id) {
	   this.jpa.deleteById(id);
   }
  
  public OrderM createO(Integer id, OrderM o) {
	    // Retrieve MobileB entity or throw exception if not found
	    MobileB mb = jpa.findById(id).orElseThrow(() -> new EntityNotFoundException("Mobile not found with ID: " + id));
	    
	    // Map MobileB details to the Order entity
	    o.setmName(mb.getmName());
	    o.setBrand(mb.getBrand());
	    o.setPrice(mb.getPrice());
	    o.setImage(mb.getImage());

	    // Save the Order entity and return it
	    return ojpa.save(o);
	}
  
  public List<OrderM> createOrders(List<Integer> ids, List<OrderM> orders) {
	    // Validate the input size
	    if (ids.size() != orders.size()) {
	        throw new IllegalArgumentException("The size of IDs and Orders must match.");
	    }

	    List<OrderM> createdOrders = new ArrayList<>();

	    for (int i = 0; i < ids.size(); i++) {
	        Integer id = ids.get(i);
	        OrderM o = orders.get(i);

	        // Retrieve MobileB entity or throw exception if not found
	        MobileB mb = jpa.findById(id)
	                        .orElseThrow(() -> new EntityNotFoundException("Mobile not found with ID: " + id));

	        // Map MobileB details to the Order entity
	        o.setmName(mb.getmName());
	        o.setBrand(mb.getBrand());
	        o.setPrice(mb.getPrice());
	        o.setImage(mb.getImage());

	        // Save and collect the created order
	        createdOrders.add(ojpa.save(o));
	    }

	    return createdOrders;
	}


}
