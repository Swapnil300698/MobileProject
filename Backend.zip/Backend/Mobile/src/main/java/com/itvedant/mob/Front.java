package com.itvedant.mob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mobile")
public class Front {
	@Autowired
	private MyService ser;
	
	@PostMapping("")
	public ResponseEntity<MobileB> createMobile(@RequestBody MobileF mf){
		return ResponseEntity.ok(this.ser.createM(mf));
	}

	@PostMapping("just")
	public ResponseEntity<String> just(){
		return ResponseEntity.ok("Hello Batch201");	
	}
	@GetMapping("")
	public ResponseEntity<?> show(){
		return ResponseEntity.ok(this.ser.showM());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getOneMob(@PathVariable Integer id) throws Exception{
		return ResponseEntity.ok(this.ser.getM(id));
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<?> updateMob(@PathVariable Integer id, @RequestBody MobileF mf) throws Exception{
		return ResponseEntity.ok(this.ser.updateM(id, mf));
	}

	@GetMapping("/paging")
	public ResponseEntity<?> showPageMob(
		@RequestParam(defaultValue="0")	int page,
		@RequestParam(defaultValue="3")	int size,
		@RequestParam(defaultValue="mName")	String sortBy
			){
		return ResponseEntity.ok(this.ser.showPM(page,size,sortBy));
	}
	
	@DeleteMapping("/{id}")
	public void deleteMob(@PathVariable Integer id) throws Exception{
		this.ser.deleteM(id);
	}
	
	@PostMapping("/order/{id}")
    public ResponseEntity<?> createOrder(@PathVariable Integer id,OrderM o) {
        try {
            OrderM createdOrder = ser.createO(id,o);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdOrder);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
